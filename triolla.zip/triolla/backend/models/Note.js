const mongoose = require("mongoose");

const NoteSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, "Task title is required"],
    trim: true,
    maxlength: [100, "Task title must be up to 100 chars"],
    minlength: [2, "Task title must be at least 2 chars"],
  },
  content: {
    type: String,
    required: [true, "Task title is required"],
    trim: true,
    maxlength: [1000, "Task title must be up to 1000 chars"],
    minlength: [2, "Task title must be at least 2 chars"],
    created_at: { type: Date, default: Date.now() },
  },
});

NoteSchema.pre("create", preSaveMiddleware);
async function preSaveMiddleware(next) {
  this.createdAt = new Date();
  next();
}

module.exports = mongoose.model("Note", NoteSchema);
