import "./NoteDetails.css";

const NoteDetails = () => {
  return (
    <div className="note-details-container">
      <div className="details-and-comments">
        <h3>Details and comments...</h3>
      </div>
      <div className="plus-button">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="65"
          height="65"
          viewBox="0 0 65 65"
          fill="none"
        >
          <path
            d="M32.5 64C49.897 64 64 49.897 64 32.5C64 15.103 49.897 1 32.5 1C15.103 1 1 15.103 1 32.5C1 49.897 15.103 64 32.5 64Z"
            stroke="#07C7A4"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
          <path
            d="M33 20V45"
            stroke="#07C7A4"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
          <path
            d="M20 33H45"
            stroke="#07C7A4"
            stroke-width="2"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
        </svg>
      </div>
    </div>
  );
};

export default NoteDetails;
