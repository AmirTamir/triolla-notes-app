export interface Note {
  _id: string;
  title: string;
  content: string;
  // --v
  // created_at: string;
}
