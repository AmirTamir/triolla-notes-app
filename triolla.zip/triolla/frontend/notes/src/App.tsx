import { useState } from "react";
import {
  createBrowserRouter,
  RouterProvider,
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";
import { Note } from "./models/Note";
import NotesList from "./components/NotesList/NotesList";
import "./App.css";
import AddNote from "./components/AddNote";

function App() {
  const [notes, setNotes] = useState<Note[]>([
    {
      _id: "1",
      title: "Note 1",
      content: "This is the first note.",
    },
    {
      _id: "2",
      title: "Note 2",
      content: "This is the second note.",
    },
  ]);

  const router = createBrowserRouter([
    {
      path: "/",
      element: <NotesList notes={notes} />,
      children: [
        {
          path: "/notes/add-note",
          element: (
            <AddNote
              onSubmit={(title, content) =>
                setNotes([
                  ...notes,
                  { title, content, _id: (notes.length + 1).toString() },
                ])
              }
            />
          ),
        },
      ],
    },
  ]);
  return (
    <div className="wrapper">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<NotesList notes={notes} />}>
            <Route index element={<NotesList notes={notes} />} />
            <Route
              path="notes/add-note"
              element={
                <AddNote
                  onSubmit={(title, content) =>
                    setNotes([
                      ...notes,
                      { title, content, _id: (notes.length + 1).toString() },
                    ])
                  }
                />
              }
            />
          </Route>
        </Routes>
      </BrowserRouter>
    </div>
  );

  //return <RouterProvider router={router} />;
}

export default App;
