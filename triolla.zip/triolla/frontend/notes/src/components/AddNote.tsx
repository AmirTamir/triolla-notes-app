import React, { useState } from "react";
import { Link } from "react-router-dom";

interface AddNoteProps {
  onSubmit: (title: string, content: string) => void;
}

const AddNote = ({ onSubmit }: AddNoteProps) => {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  const handleTitleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setTitle(event.target.value);
  };

  const handleContentChange = (
    event: React.ChangeEvent<HTMLTextAreaElement>
  ) => {
    setContent(event.target.value);
  };

  const handleSubmit = () => {
    onSubmit(title, content);
  };

  return (
    <div>
      <h1>Add New Note</h1>
      <input
        type="text"
        placeholder="Title"
        value={title}
        onChange={handleTitleChange}
      />
      <textarea
        placeholder="Content"
        value={content}
        onChange={handleContentChange}
      />
      <button onClick={handleSubmit}>Submit</button>
      <Link to="/">Back to Notes List</Link>
    </div>
  );
};

export default AddNote;
