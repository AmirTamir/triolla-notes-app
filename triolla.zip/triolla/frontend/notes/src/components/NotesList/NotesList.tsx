import "./NotesList.css";
import { Link } from "react-router-dom";

import { Note } from "../../models/Note";
import NoteDetails from "../NoteDetails/NoteDetails";

interface NotesListProps {
  notes: Note[];
}

const NotesList = ({ notes }: NotesListProps) => {
  return (
    <div className="notes-list-wrapper">
      <div className="notes-titles-section">
        <ul>
          {notes.map((note) => (
            <li key={note._id}>
              <Link to={`/note/${note._id}`}>{note.title}</Link>
            </li>
          ))}
        </ul>
        <button>
          <Link to="/notes/add-note">Add New Note</Link>
        </button>
      </div>
      <div className="details-section">
        <NoteDetails />
      </div>
    </div>
  );
};

export default NotesList;
