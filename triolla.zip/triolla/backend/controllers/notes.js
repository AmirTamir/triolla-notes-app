// const Task = require("../models/Task");
const Note = require("../models/Note");
const asyncWrapper = require("../middleware/async");
const { createCustomError, CustomAPIError } = require("../errors/custom-error");

const getAllNotes = asyncWrapper(async (req, res) => {
  const notes = await Note.find({});
  res.status(200).json({ notes });
});

const createNote = asyncWrapper(async (req, res) => {
  const newNote = req.body;
  const createdAt = new Date(Date.now());
  newNote.created_at = createdAt;
  const task = await Note.create(newNote);
  res.status(201).json({ task });
});

module.exports = {
  getAllNotes,
  createNote,
};
