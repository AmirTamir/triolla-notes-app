const express = require("express");
const router = express.Router();
const { getAllNotes, createNote } = require("../controllers/notes");

router.route("/").get(getAllNotes).post(createNote);
//router.route("/:id").get(getTask).patch(updateTask).delete(deleteTask);

module.exports = router;
